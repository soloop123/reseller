@php
    /*
    |--------------------------------------------------------------------------
    | SoloCloud color templates
    |--------------------------------------------------------------------------
    | Every template ships a real light AND dark palette (HSL "h s% l%").
    | "custom" falls back to the color pickers in the theme settings.
    | Keys: primary, secondary, neutral (borders), base (text), muted (text),
    |       inverted (text ON primary buttons), background, background-secondary,
    |       info (glow accent).
    */
    $presets = [
        'water' => [
            'light' => [
                'primary' => '201 96% 40%', 'secondary' => '210 100% 40%', 'neutral' => '214 32% 88%',
                'base' => '222 47% 11%', 'muted' => '215 16% 40%', 'inverted' => '0 0% 100%',
                'background' => '210 40% 98%', 'background-secondary' => '0 0% 100%', 'info' => '190 90% 40%',
            ],
            'dark' => [
                'primary' => '199 100% 50%', 'secondary' => '210 100% 40%', 'neutral' => '223 24% 16%',
                'base' => '210 40% 98%', 'muted' => '215 20% 65%', 'inverted' => '0 0% 100%',
                'background' => '224 71% 4%', 'background-secondary' => '223 49% 8%', 'info' => '186 100% 50%',
            ],
        ],
        'fire' => [
            'light' => [
                'primary' => '36 96% 44%', 'secondary' => '18 90% 48%', 'neutral' => '35 30% 86%',
                'base' => '20 40% 9%', 'muted' => '25 15% 38%', 'inverted' => '20 60% 6%',
                'background' => '40 33% 97%', 'background-secondary' => '0 0% 100%', 'info' => '28 95% 50%',
            ],
            'dark' => [
                'primary' => '45 100% 52%', 'secondary' => '24 95% 53%', 'neutral' => '25 25% 17%',
                'base' => '40 30% 97%', 'muted' => '30 12% 65%', 'inverted' => '20 60% 6%',
                'background' => '20 30% 5%', 'background-secondary' => '20 25% 9%', 'info' => '30 100% 55%',
            ],
        ],
        'datacenter' => [
            'light' => [
                'primary' => '150 80% 32%', 'secondary' => '172 75% 30%', 'neutral' => '210 16% 87%',
                'base' => '210 25% 10%', 'muted' => '210 10% 38%', 'inverted' => '0 0% 100%',
                'background' => '210 20% 96%', 'background-secondary' => '0 0% 100%', 'info' => '160 80% 35%',
            ],
            'dark' => [
                'primary' => '146 80% 45%', 'secondary' => '172 70% 38%', 'neutral' => '210 14% 18%',
                'base' => '210 20% 96%', 'muted' => '210 10% 62%', 'inverted' => '150 60% 5%',
                'background' => '210 18% 6%', 'background-secondary' => '210 16% 10%', 'info' => '160 90% 50%',
            ],
        ],
        'minecraft' => [
            'light' => [
                'primary' => '102 62% 30%', 'secondary' => '195 85% 33%', 'neutral' => '30 25% 78%',
                'base' => '25 30% 12%', 'muted' => '25 12% 36%', 'inverted' => '0 0% 100%',
                'background' => '200 60% 94%', 'background-secondary' => '0 0% 100%', 'info' => '40 90% 45%',
            ],
            'dark' => [
                'primary' => '100 60% 45%', 'secondary' => '190 80% 50%', 'neutral' => '25 20% 24%',
                'base' => '60 20% 95%', 'muted' => '30 12% 68%', 'inverted' => '110 50% 6%',
                'background' => '25 25% 8%', 'background-secondary' => '25 22% 13%', 'info' => '45 95% 55%',
            ],
        ],
    ];

    // Accepts "hsl(199, 100%, 50%)" / "hsl(199 100% 50%)" / "199 100% 50%"; anything else -> fallback.
    $toTriplet = function ($value, $fallback) {
        if (is_string($value) && preg_match('/^(?:hsl\(\s*)?([\d.]+)(?:deg)?[\s,]+([\d.]+)%[\s,]+([\d.]+)%\s*\)?$/i', trim($value), $m)) {
            return "{$m[1]} {$m[2]}% {$m[3]}%";
        }
        return $fallback;
    };

    $template = theme('template', 'water');

    if ($template === 'custom' || !isset($presets[$template])) {
        $base = $presets['water'];
        $custom = function (string $mode, string $prefix) use ($toTriplet, $base) {
            $out = $base[$mode];
            foreach (['primary', 'secondary', 'neutral', 'base', 'muted', 'inverted', 'background', 'background-secondary'] as $key) {
                $out[$key] = $toTriplet(theme($prefix . $key), $base[$mode][$key]);
            }
            return $out;
        };
        $light = $custom('light', '');
        $dark = $custom('dark', 'dark-');
        $template = 'custom';
    } else {
        $light = $presets[$template]['light'];
        $dark = $presets[$template]['dark'];
    }

    // ---- Background image: each template has its own picture ----
    // Default (Custom) has none unless an image URL is entered in the settings.
    $templateBackgrounds = [
        'water' => 'mc-snow',
        'fire' => 'bees',
        'datacenter' => 'cloud-3d',
        'minecraft' => 'mc-forest',
    ];
    $bg = $templateBackgrounds[$template] ?? 'none';
    $customBgCss = null;
    if ($template === 'custom') {
        $url = trim((string) theme('background_custom_url', ''));
        // only http(s) links or site-relative paths; refuse anything that could break out of url()
        $validStart = str_starts_with($url, '/') ? !str_starts_with($url, '//') : (bool) preg_match('~^https?://~i', $url);
        if ($url !== '' && $validStart && strpbrk($url, " \t\r\n'\"()<>\\{};") === false) {
            $customBgCss = $url;
            $bg = 'custom';
        }
    }
    $brightness = max(1, min(200, (int) preg_replace('/[^0-9]/', '', (string) theme('background_brightness', '100')) ?: 100)) / 100;
    $overlayAlpha = ['light' => 0.3, 'medium' => 0.5, 'strong' => 0.75][theme('background_overlay', 'medium')] ?? 0.7;

    $vars = function (array $c) {
        $css = '';
        foreach ($c as $key => $value) {
            $css .= "--color-{$key}: {$value};\n        ";
        }
        return $css;
    };
@endphp
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
@if ($template === 'minecraft')
<link href="https://fonts.googleapis.com/css2?family=Pixelify+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
@endif

<style>
    :root {
        color-scheme: light;
        /* Branding / neutral / text / background — LIGHT */
        {!! $vars($light) !!}
        /* State Colors */
        --color-success: 142 71% 38%;
        --color-error: 0 75% 52%;
        --color-warning: 38 100% 45%;
        --color-inactive: 215 14% 45%;
    }

    .dark {
        color-scheme: dark;
        /* Branding / neutral / text / background — DARK */
        {!! $vars($dark) !!}
        --color-success: 142 71% 45%;
        --color-error: 0 75% 60%;
        --color-warning: 42 100% 50%;
        --color-inactive: 215 14% 45%;
    }
</style>
@php
    // Per-page theme state lives on <body> (see layouts/app.blade.php). <body> is swapped on every
    // wire:navigate visit, so the background / font / template styling can never get lost
    // when moving between pages (inline <script>s and <html> attributes are NOT re-applied by Livewire).
    $bodyStyle = '--solo-overlay: ' . $overlayAlpha . '; --solo-brightness: ' . $brightness . ';';
    if ($customBgCss) {
        $bodyStyle .= " --solo-custom-bg: url('" . $customBgCss . "');";
    }
    config(['solo.state' => ['template' => $template, 'bg' => $bg, 'vars' => [
        '--solo-overlay' => (string) $overlayAlpha,
        '--solo-brightness' => (string) $brightness,
    ] + ($customBgCss ? ['--solo-custom-bg' => "url('" . $customBgCss . "')"] : [])]]);
    config(['solo.body_attrs' => 'data-solo-template="' . e($template) . '" data-solo-bg="' . e($bg) . '" style="' . e($bodyStyle) . '"']);
@endphp
