<?php

namespace Paymenter\Extensions\Servers\ResellerChild;

use App\Attributes\ExtensionMeta;
use App\Classes\Extension\Server;
use App\Models\Service;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\View;
use Livewire\Livewire;
use Paymenter\Extensions\Servers\ResellerChild\Livewire\ResellerPortal;
use Paymenter\Extensions\Servers\ResellerChild\Support\HostConfig;
use Paymenter\Extensions\Servers\ResellerChild\Support\ParentClient;

#[ExtensionMeta(
    name: 'Reseller Child',
    description: 'Resell the products of a parent Paymenter. A dedicated reseller account picks parent products, sets its own prices and publishes them; orders are provisioned on the parent automatically.',
    version: '1.0.0',
    author: 'SoloCloud',
)]
class ResellerChild extends Server
{
    public function getConfig($values = []): array
    {
        return [
            [
                'name' => 'parent_url',
                'label' => 'Parent billing URL',
                'type' => 'text',
                'description' => 'Base URL of the wholesale Paymenter, e.g. https://billing.solocloud.example',
                'required' => true,
                'validation' => 'url',
            ],
            [
                'name' => 'api_key',
                'label' => 'Reseller API key',
                'type' => 'text',
                'description' => 'Created under Admin → Resellers on the parent panel.',
                'required' => true,
                'encrypted' => true,
            ],
            [
                'name' => 'portal_users',
                'label' => 'Reseller portal accounts',
                'type' => 'text',
                'description' => 'Comma separated e-mail addresses of customer accounts allowed to open the Reseller portal (account menu → Reseller). These accounts can import parent products and set prices, but have no admin access.',
                'required' => false,
            ],
            [
                'name' => 'allow_below_wholesale',
                'label' => 'Allow selling below wholesale price',
                'type' => 'checkbox',
                'description' => 'When off (recommended) the portal refuses prices lower than the parent\'s wholesale price.',
                'default' => false,
            ],
        ];
    }

    public function testConfig(): bool|string
    {
        try {
            ParentClient::fromSettings(HostConfig::active() ? HostConfig::settings() : $this->config)->me();
        } catch (Exception $e) {
            return $e->getMessage();
        }

        return true;
    }

    public function getProductConfig($values = []): array
    {
        return [
            [
                'name' => 'parent_product_id',
                'label' => 'Parent product ID',
                'type' => 'number',
                'description' => 'ID of the product on the parent panel. Normally filled in by the Reseller portal. Billing cycles are matched by period automatically.',
                'required' => true,
            ],
        ];
    }

    public function createServer(Service $service, $settings, $properties)
    {
        // Already provisioned (job retried / re-run)
        if (!empty($properties['parent_service_id'])) {
            return [];
        }

        $client = $this->client();
        $parentProduct = $client->product((int) ($settings['parent_product_id'] ?? 0));

        $plan = collect($parentProduct['plans'])->first(
            fn ($p) => $p['type'] === $service->plan->type
                && (int) $p['billing_period'] === (int) $service->plan->billing_period
                && $p['billing_unit'] === $service->plan->billing_unit
        );

        if (!$plan) {
            throw new Exception('The parent product has no billing cycle matching plan "' . ($service->plan->name ?? $service->plan_id) . '".');
        }

        $remote = $client->createService(
            (int) $parentProduct['id'],
            (int) $plan['id'],
            $service->currency_code,
            (string) $service->id,
            $service->product->name . ' #' . $service->id,
        );

        $service->properties()->updateOrCreate(
            ['key' => 'parent_service_id'],
            ['name' => 'Parent service ID', 'value' => $remote['id']]
        );

        return [];
    }

    public function suspendServer(Service $service, $settings, $properties)
    {
        $this->client()->suspend($this->remoteId($properties));

        return true;
    }

    public function unsuspendServer(Service $service, $settings, $properties)
    {
        $this->client()->unsuspend($this->remoteId($properties));

        return true;
    }

    public function terminateServer(Service $service, $settings, $properties)
    {
        // Never provisioned on the parent: nothing to remove
        if (empty($properties['parent_service_id'])) {
            return true;
        }

        $this->client()->terminate((int) $properties['parent_service_id']);

        return true;
    }

    public function boot()
    {
        require __DIR__ . '/routes/web.php';

        View::addNamespace('reseller-child', __DIR__ . '/resources/views');
        Livewire::component('reseller-portal', ResellerPortal::class);

        Event::listen('navigation.account', function () {
            if (!Auth::check() || !ResellerPortal::isAllowed(Auth::user())) {
                return null;
            }

            return [
                'name' => 'Reseller',
                'route' => 'reseller.portal',
                'priority' => 16,
            ];
        });
    }

    protected function client(): ParentClient
    {
        if (HostConfig::active()) {
            return ParentClient::fromSettings(HostConfig::settings());
        }

        return ParentClient::fromSettings([
            'parent_url' => $this->config('parent_url'),
            'api_key' => $this->config('api_key'),
        ]);
    }

    protected function remoteId(array $properties): int
    {
        if (empty($properties['parent_service_id'])) {
            throw new Exception('This service has not been provisioned on the parent panel.');
        }

        return (int) $properties['parent_service_id'];
    }
}
