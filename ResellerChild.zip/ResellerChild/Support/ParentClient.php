<?php

namespace Paymenter\Extensions\Servers\ResellerChild\Support;

use Exception;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/**
 * Thin client for the Reseller Parent API running on the wholesale panel.
 */
class ParentClient
{
    public function __construct(protected string $url, protected string $key) {}

    public static function fromSettings(array $settings): self
    {
        if (empty($settings['parent_url']) || empty($settings['api_key'])) {
            throw new Exception('Parent URL or API key is not configured.');
        }

        return new self($settings['parent_url'], $settings['api_key']);
    }

    public function request(string $method, string $path, array $data = []): array
    {
        $response = Http::withToken($this->key)
            ->acceptJson()
            ->asJson()
            ->timeout(30)
            ->$method(rtrim($this->url, '/') . '/api/reseller/v1' . $path, $data);

        if (!$response->successful()) {
            $message = $response->json('error')
                ?? $response->json('message')
                ?? ('Parent panel returned HTTP ' . $response->status());

            throw new Exception('Parent panel: ' . $message, $response->status());
        }

        return $response->json() ?? [];
    }

    public function me(): array
    {
        return $this->request('get', '/me');
    }

    /**
     * Catalog is cached briefly so the portal stays fast.
     */
    public function products(bool $fresh = false): array
    {
        $key = 'reseller-child.catalog.' . md5($this->url . $this->key);

        if ($fresh) {
            Cache::forget($key);
        }

        return Cache::remember($key, 60, fn () => $this->request('get', '/products')['data'] ?? []);
    }

    public function product(int $id): array
    {
        return $this->request('get', '/products/' . $id)['data'];
    }

    public function createService(int $productId, int $planId, string $currency, string $reference, ?string $label = null): array
    {
        return $this->request('post', '/services', array_filter([
            'product_id' => $productId,
            'plan_id' => $planId,
            'currency' => $currency,
            'reference' => $reference,
            'label' => $label,
        ], fn ($v) => $v !== null))['data'];
    }

    public function suspend(int $serviceId): array
    {
        return $this->request('post', "/services/{$serviceId}/suspend")['data'];
    }

    public function unsuspend(int $serviceId): array
    {
        return $this->request('post', "/services/{$serviceId}/unsuspend")['data'];
    }

    public function terminate(int $serviceId): array
    {
        return $this->request('post', "/services/{$serviceId}/terminate")['data'];
    }
}
