<?php

namespace Paymenter\Extensions\Servers\ResellerChild\Support;

use App\Models\Server;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Run once by the egg after the extension files are in place (php artisan tinker). Creates the server record the
 * imported products attach to and switches the extension on.
 *
 * NOTE: written against Paymenter's Server / Extension models as used elsewhere in this extension. Check the log line
 * "[ResellerChild] bootstrap" in storage/logs if the extension does not show up as enabled on a fresh store.
 */
class Bootstrap
{
    public static function run(): void
    {
        try {
            Server::firstOrCreate(['extension' => 'ResellerChild'], ['name' => 'SoloCloud Wholesale']);
        } catch (Throwable $e) {
            Log::error('[ResellerChild] bootstrap (server row): ' . $e->getMessage());
            throw $e;
        }

        try {
            $model = '\\App\\Models\\Extension';
            if (class_exists($model)) {
                $model::updateOrCreate(['extension' => 'ResellerChild', 'type' => 'server'], ['enabled' => true]);
            }
        } catch (Throwable $e) {
            Log::error('[ResellerChild] bootstrap (enable): ' . $e->getMessage());
        }
    }
}
