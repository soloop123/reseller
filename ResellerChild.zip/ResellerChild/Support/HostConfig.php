<?php

namespace Paymenter\Extensions\Servers\ResellerChild\Support;

/**
 * "Hosted" mode: this store runs inside a SoloCloud Store Host server. Its connection to the wholesale panel and the
 * secret used by SoloCloud billing to manage it come from the store's .env (written by the egg on every start),
 * so the reseller never types or sees them and there is no admin to configure anything.
 */
class HostConfig
{
    public static function get(string $key): ?string
    {
        $value = env($key);
        if ($value !== null && $value !== '') {
            return (string) $value;
        }

        $file = base_path('.env');
        if (is_file($file)) {
            foreach (file($file, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
                if (str_starts_with($line, $key . '=')) {
                    $v = trim(substr($line, strlen($key) + 1), " \t\"'");

                    return $v === '' ? null : $v;
                }
            }
        }

        return null;
    }

    public static function active(): bool
    {
        return (bool) self::get('HOST_MGMT_SECRET');
    }

    /** Settings in the same shape the extension's own config uses. */
    public static function settings(): array
    {
        return [
            'parent_url' => self::get('HOST_PARENT_URL'),
            'api_key' => self::get('HOST_PARENT_KEY'),
            'allow_below_wholesale' => false,
            'portal_users' => '',
        ];
    }
}
