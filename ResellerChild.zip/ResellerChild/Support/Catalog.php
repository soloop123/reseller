<?php

namespace Paymenter\Extensions\Servers\ResellerChild\Support;

use App\Models\Category;
use App\Models\Currency;
use App\Models\Plan;
use App\Models\Product;
use App\Models\Server;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Plans and pricing of the reseller's store, driven by the management API (the SoloCloud service page).
 * Same rules as the in-store Reseller portal: prices can never be below wholesale, and only products imported
 * through here can be touched.
 */
class Catalog
{
    public function __construct(protected ParentClient $client) {}

    public static function make(): self
    {
        return new self(ParentClient::fromSettings(HostConfig::settings()));
    }

    protected function server(): Server
    {
        return Server::where('extension', 'ResellerChild')->firstOrFail();
    }

    protected function currencies(): array
    {
        return Currency::pluck('code')->all();
    }

    /** @return \Illuminate\Database\Eloquent\Collection<int, Product> */
    protected function managed()
    {
        return Product::where('server_id', $this->server()->id)
            ->whereHas('settings', fn ($q) => $q->where('key', 'reseller_managed')->where('value', '1'))
            ->with(['plans.prices', 'settings', 'category'])
            ->orderBy('id')->get();
    }

    protected function parentId(Product $p): ?int
    {
        $v = $p->settings->firstWhere('key', 'parent_product_id')?->value;

        return $v === null ? null : (int) $v;
    }

    protected function matchPlan(Product $product, array $pp): ?Plan
    {
        return $product->plans->first(fn (Plan $plan) => $plan->type === $pp['type']
            && (int) $plan->billing_period === (int) $pp['billing_period']
            && $plan->billing_unit === $pp['billing_unit']);
    }

    /** Everything the service page needs in one call. */
    public function state(bool $fresh = false): array
    {
        $catalog = collect($this->client->products($fresh));
        $currencies = $this->currencies();
        $managed = $this->managed();
        $imported = $managed->map(fn ($p) => $this->parentId($p))->all();

        $products = $managed->map(function (Product $product) use ($catalog) {
            $parent = $catalog->firstWhere('id', $this->parentId($product));
            $cycles = [];
            foreach ($parent['plans'] ?? [] as $pp) {
                $mine = $this->matchPlan($product, $pp);
                $prices = [];
                foreach ($pp['prices'] as $w) {
                    $m = $mine?->prices->firstWhere('currency_code', $w['currency']);
                    $prices[$w['currency']] = [
                        'price' => $m ? (string) $m->price : '',
                        'setup_fee' => $m ? (string) ($m->setup_fee ?? 0) : '',
                        'wholesale' => $w['price'],
                        'wholesale_setup' => $w['setup_fee'],
                    ];
                }
                $cycles[] = ['plan_id' => $pp['id'], 'name' => $pp['name'], 'type' => $pp['type'], 'enabled' => (bool) $mine, 'prices' => $prices];
            }

            return [
                'id' => $product->id,
                'parent_product_id' => $this->parentId($product),
                'name' => $product->name,
                'description' => (string) $product->description,
                'category' => $product->category?->name,
                'visible' => !$product->hidden,
                'customers' => $product->services()->count(),
                'cycles' => $cycles,
            ];
        })->values()->all();

        $available = $catalog->reject(fn ($p) => in_array($p['id'], $imported))->map(fn ($p) => [
            'id' => $p['id'],
            'name' => $p['name'],
            'description' => $p['description'] ?? '',
            'supported' => $p['supported'],
            'unsupported_reason' => $p['unsupported_reason'] ?? null,
            'cycles' => collect($p['plans'])->map(fn ($pp) => [
                'plan_id' => $pp['id'], 'name' => $pp['name'], 'type' => $pp['type'], 'enabled' => true,
                'prices' => collect($pp['prices'])->mapWithKeys(fn ($w) => [$w['currency'] => [
                    'price' => (string) max($w['list_price'], $w['price']), 'setup_fee' => (string) $w['setup_fee'],
                    'wholesale' => $w['price'], 'wholesale_setup' => $w['setup_fee'],
                ]])->all(),
            ])->values()->all(),
        ])->values()->all();

        return [
            'currencies' => $currencies,
            'balance' => $this->client->me()['credits'] ?? [],
            'products' => $products,
            'available' => $available,
        ];
    }

    /**
     * Create or update one product. $in: parent_product_id, product_id?, name, description, category, visible, cycles[plan_id] => [enabled, prices[CUR] => [price, setup_fee]]
     *
     * @throws Exception message is safe to show to the reseller
     */
    public function save(array $in): void
    {
        $parent = $this->client->product((int) ($in['parent_product_id'] ?? 0));
        if (!$parent['supported']) {
            throw new Exception($parent['unsupported_reason'] ?? 'This product cannot be resold yet.');
        }

        $name = trim((string) ($in['name'] ?? ''));
        $category = trim((string) ($in['category'] ?? ''));
        if ($name === '' || mb_strlen($name) > 100) {
            throw new Exception('Enter a product name (max 100 characters).');
        }
        if ($category === '' || mb_strlen($category) > 100) {
            throw new Exception('Enter a category name (max 100 characters).');
        }

        $currencies = $this->currencies();
        $chosen = [];
        foreach ($parent['plans'] as $pp) {
            $cycle = $in['cycles'][$pp['id']] ?? null;
            if (!$cycle || empty($cycle['enabled'])) {
                continue;
            }
            $prices = [];
            if ($pp['type'] !== 'free') {
                foreach ($pp['prices'] as $w) {
                    $input = $cycle['prices'][$w['currency']] ?? [];
                    $price = trim((string) ($input['price'] ?? ''));
                    if (!in_array($w['currency'], $currencies, true) || $price === '') {
                        continue;
                    }
                    $setup = trim((string) ($input['setup_fee'] ?? '')) === '' ? '0' : trim((string) $input['setup_fee']);
                    if (!is_numeric($price) || !is_numeric($setup) || $price < 0 || $setup < 0 || $price > 9999999 || $setup > 9999999) {
                        throw new Exception("Invalid price for {$pp['name']} ({$w['currency']}).");
                    }
                    if ($price < $w['price'] || $setup < $w['setup_fee']) {
                        throw new Exception("{$pp['name']} ({$w['currency']}): price and setup fee can not be lower than your wholesale cost ({$w['price']} / {$w['setup_fee']}).");
                    }
                    $prices[$w['currency']] = ['price' => round((float) $price, 2), 'setup_fee' => round((float) $setup, 2)];
                }
                if (!$prices) {
                    throw new Exception("Set a price for {$pp['name']} in at least one currency, or switch that billing cycle off.");
                }
            }
            $chosen[$pp['id']] = $prices;
        }
        if (!$chosen) {
            throw new Exception('Enable at least one billing cycle.');
        }

        DB::transaction(function () use ($in, $parent, $name, $category, $chosen) {
            $cat = Category::where('name', $category)->first()
                ?? Category::create(['name' => $category, 'slug' => Str::slug($category) . '-' . Str::lower(Str::random(4))]);

            if (!empty($in['product_id'])) {
                $product = $this->managed()->firstWhere('id', (int) $in['product_id']) ?? throw new Exception('Product not found.');
                if ($this->parentId($product) !== (int) $parent['id']) {
                    throw new Exception('Product mismatch.');
                }
                $product->update(['name' => $name, 'description' => $in['description'] ?? '', 'category_id' => $cat->id, 'hidden' => empty($in['visible'])]);
            } else {
                if ($this->managed()->contains(fn ($p) => $this->parentId($p) === (int) $parent['id'])) {
                    throw new Exception('You already added this product. Edit it instead.');
                }
                $product = Product::create([
                    'category_id' => $cat->id,
                    'name' => $name,
                    'slug' => Str::slug($name) . '-' . Str::lower(Str::random(5)),
                    'description' => $in['description'] ?? '',
                    'server_id' => $this->server()->id,
                    'hidden' => empty($in['visible']),
                    'allow_quantity' => 'disabled',
                ]);
                $product->settings()->updateOrCreate(['key' => 'parent_product_id'], ['value' => (string) $parent['id'], 'type' => 'string']);
                $product->settings()->updateOrCreate(['key' => 'reseller_managed'], ['value' => '1', 'type' => 'string']);
            }

            $product->load('plans.prices');
            foreach ($parent['plans'] as $i => $pp) {
                $plan = $this->matchPlan($product, $pp);
                if (!array_key_exists($pp['id'], $chosen)) {
                    if ($plan && !$plan->services()->exists()) {
                        $plan->prices()->delete();
                        $plan->delete();
                    }

                    continue;
                }
                $plan ??= $product->plans()->create([
                    'name' => $pp['name'], 'type' => $pp['type'], 'billing_period' => $pp['billing_period'],
                    'billing_unit' => $pp['billing_unit'], 'sort' => $i,
                ]);
                $plan->prices()->whereNotIn('currency_code', array_keys($chosen[$pp['id']]) ?: [''])->delete();
                foreach ($chosen[$pp['id']] as $cur => $amounts) {
                    $plan->prices()->updateOrCreate(['currency_code' => $cur], $amounts);
                }
            }
        });
    }

    public function toggle(int $id): bool
    {
        $p = $this->managed()->firstWhere('id', $id) ?? throw new Exception('Product not found.');
        $p->update(['hidden' => !$p->hidden]);

        return !$p->hidden;
    }

    public function remove(int $id): string
    {
        $p = $this->managed()->firstWhere('id', $id) ?? throw new Exception('Product not found.');
        if ($p->services()->exists()) {
            $p->update(['hidden' => true]);

            return 'Customers already own this product, so it was hidden instead of deleted.';
        }
        DB::transaction(function () use ($p) {
            foreach ($p->plans as $plan) {
                $plan->prices()->delete();
                $plan->delete();
            }
            $p->settings()->delete();
            $p->delete();
        });

        return 'Product removed.';
    }
}
