<div class="container mt-14">
    <x-navigation.breadcrumb />

    <div class="px-2 mt-4 flex flex-col gap-6">

        <div class="flex flex-wrap items-start justify-between gap-4">
            <div>
                <h1 class="text-2xl font-semibold">Reseller</h1>
                <p class="text-gray-500 text-sm">Pick products from the parent catalog, set your own prices and make them public in your store.</p>
            </div>
            <div class="flex flex-col gap-1 bg-background-secondary p-4 rounded-lg min-w-48">
                <span class="text-sm text-gray-500">Wholesale credit at parent</span>
                @forelse ($balance as $code => $amount)
                    <span class="text-xl font-semibold">{{ $code }} {{ number_format($amount, 2) }}</span>
                @empty
                    <span class="text-xl font-semibold text-yellow-500">0.00</span>
                @endforelse
                <span class="text-xs text-gray-500">Orders and renewals are paid from this balance. Keep it topped up.</span>
            </div>
        </div>

        @if ($error)
            <div class="bg-red-500/10 border border-red-500/40 text-red-400 rounded-lg p-4 text-sm">
                Could not reach the parent billing: {{ $error }}
            </div>
        @endif

        {{-- ADD / EDIT FORM --}}
        @if ($form)
            <form wire:submit.prevent="save" class="bg-background-secondary rounded-lg p-5 flex flex-col gap-4">
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-semibold">
                        {{ $form['product_id'] ? 'Edit' : 'Add' }}: {{ $editingParent['name'] ?? '' }}
                    </h2>
                    <button type="button" wire:click="cancel" class="text-sm text-gray-500 hover:underline">Cancel</button>
                </div>

                <div class="grid md:grid-cols-2 gap-4">
                    <x-form.input name="form.name" label="Name in your store" wire:model="form.name" required />
                    <fieldset class="flex flex-col w-full">
                        <label class="mb-1 text-sm text-primary-100">Category</label>
                        <select wire:model="form.category_id"
                            class="block w-full text-sm bg-background-secondary border border-neutral rounded-md px-2.5 py-2.5">
                            <option value="">— choose —</option>
                            @foreach ($categories as $id => $categoryName)
                                <option value="{{ $id }}">{{ $categoryName }}</option>
                            @endforeach
                        </select>
                    </fieldset>
                    <x-form.input name="form.new_category" label="…or create a new category" wire:model="form.new_category" />
                    <fieldset class="flex flex-col w-full">
                        <label class="mb-1 text-sm text-primary-100">Visibility</label>
                        <label class="flex items-center gap-2 text-sm py-2.5">
                            <input type="checkbox" wire:model="form.visible" class="rounded" />
                            Public in my store (customers can see and buy it)
                        </label>
                    </fieldset>
                </div>

                <fieldset class="flex flex-col w-full">
                    <label class="mb-1 text-sm text-primary-100">Description</label>
                    <textarea wire:model="form.description" rows="3"
                        class="block w-full text-sm bg-background-secondary border border-neutral rounded-md px-2.5 py-2.5"></textarea>
                </fieldset>

                <div class="flex flex-col gap-3">
                    <h3 class="font-semibold">Billing cycles and your prices</h3>
                    @if ($editingParent)
                        @foreach ($editingParent['plans'] as $plan)
                            <div class="border border-neutral rounded-md p-3 flex flex-col gap-2">
                                <label class="flex items-center gap-2 font-medium">
                                    <input type="checkbox" wire:model="form.cycles.{{ $plan['id'] }}.enabled" class="rounded" />
                                    {{ $plan['name'] ?: ucfirst($plan['type']) }}
                                    @if ($plan['type'] === 'recurring')
                                        <span class="text-xs text-gray-500">every {{ $plan['billing_period'] }} {{ $plan['billing_unit'] }}(s)</span>
                                    @else
                                        <span class="text-xs text-gray-500">{{ $plan['type'] }}</span>
                                    @endif
                                </label>

                                @foreach ($plan['prices'] as $wholesale)
                                    @continue(!in_array($wholesale['currency'], $currencies))
                                    <div class="grid grid-cols-2 md:grid-cols-5 gap-2 items-end">
                                        <div class="text-sm">
                                            <span class="font-semibold">{{ $wholesale['currency'] }}</span><br>
                                            <span class="text-gray-500">cost {{ number_format($wholesale['price'], 2) }}
                                                @if ($wholesale['setup_fee'] > 0) + {{ number_format($wholesale['setup_fee'], 2) }} setup @endif
                                            </span>
                                        </div>
                                        <x-form.input name="price-{{ $plan['id'] }}-{{ $wholesale['currency'] }}" label="Your price"
                                            type="number" step="0.01" min="0"
                                            wire:model="form.cycles.{{ $plan['id'] }}.prices.{{ $wholesale['currency'] }}.price" />
                                        <x-form.input name="setup-{{ $plan['id'] }}-{{ $wholesale['currency'] }}" label="Setup fee"
                                            type="number" step="0.01" min="0"
                                            wire:model="form.cycles.{{ $plan['id'] }}.prices.{{ $wholesale['currency'] }}.setup_fee" />
                                    </div>
                                @endforeach
                                @if ($plan['type'] !== 'free' && collect($plan['prices'])->pluck('currency')->intersect($currencies)->isEmpty())
                                    <p class="text-sm text-yellow-500">The parent has no price in any currency your store uses.</p>
                                @endif
                            </div>
                        @endforeach
                    @endif
                    <p class="text-xs text-gray-500">
                        Leave a price empty to not sell that cycle in that currency.
                        @unless ($allowBelow) Prices below your cost are rejected. @endunless
                    </p>
                </div>

                <div class="flex gap-2">
                    <x-button.primary type="submit" class="!w-fit">Save product</x-button.primary>
                </div>
            </form>
        @endif

        {{-- MY PRODUCTS --}}
        <div class="flex flex-col gap-3">
            <h2 class="text-lg font-semibold">My products</h2>
            @forelse ($products as $product)
                <div class="bg-background-secondary rounded-lg p-4 flex flex-col gap-3">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                        <div>
                            <span class="font-semibold">{{ $product['name'] }}</span>
                            <span class="text-xs text-gray-500 ml-2">{{ $product['category'] }} · {{ $product['services'] }} customer service(s)</span>
                            @if ($product['public'])
                                <span class="ml-2 text-xs rounded bg-green-500/15 text-green-400 px-2 py-0.5">Public</span>
                            @else
                                <span class="ml-2 text-xs rounded bg-gray-500/20 text-gray-400 px-2 py-0.5">Hidden</span>
                            @endif
                            @unless ($product['offered'])
                                <span class="ml-2 text-xs rounded bg-red-500/15 text-red-400 px-2 py-0.5">No longer offered by parent</span>
                            @endunless
                        </div>
                        <div class="flex gap-2 text-sm">
                            <button wire:click="toggleVisibility({{ $product['id'] }})" class="underline">
                                {{ $product['public'] ? 'Hide' : 'Make public' }}
                            </button>
                            @if ($product['offered'])
                                <button wire:click="startEdit({{ $product['id'] }})" class="underline">Edit prices</button>
                            @endif
                            <button wire:click="remove({{ $product['id'] }})"
                                wire:confirm="Remove this product from your store?" class="underline text-red-400">Remove</button>
                        </div>
                    </div>
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="text-left text-gray-500">
                                <th class="py-1 font-normal">Cycle</th>
                                <th class="py-1 font-normal">Currency</th>
                                <th class="py-1 font-normal">Your price</th>
                                <th class="py-1 font-normal">Your cost</th>
                                <th class="py-1 font-normal">Margin</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($product['rows'] as $row)
                                <tr>
                                    <td class="py-1">{{ $row['plan'] }}</td>
                                    <td class="py-1">{{ $row['currency'] }}</td>
                                    <td class="py-1">{{ number_format($row['retail'], 2) }}</td>
                                    <td class="py-1">{{ $row['wholesale'] !== null ? number_format($row['wholesale'], 2) : '—' }}</td>
                                    <td class="py-1 {{ $row['below'] ? 'text-red-400' : '' }}">
                                        @if ($row['wholesale'] !== null)
                                            {{ number_format($row['retail'] - $row['wholesale'], 2) }}
                                            @if ($row['below']) (below cost!) @endif
                                        @else — @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @empty
                <p class="text-sm text-gray-500">You have not added any products yet. Pick one below.</p>
            @endforelse
        </div>

        {{-- PARENT CATALOG --}}
        <div class="flex flex-col gap-3 mb-10">
            <div class="flex items-center justify-between">
                <h2 class="text-lg font-semibold">Available from parent</h2>
                <button wire:click="refreshCatalog" class="text-sm underline">Refresh</button>
            </div>
            <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
                @forelse ($available as $product)
                    <div class="bg-background-secondary rounded-lg p-4 flex flex-col gap-2">
                        <div class="font-semibold">{{ $product['name'] }}</div>
                        @if (!empty($product['category']))
                            <div class="text-xs text-gray-500">{{ $product['category']['name'] }}</div>
                        @endif
                        <ul class="text-sm text-gray-400">
                            @foreach ($product['plans'] as $plan)
                                <li>
                                    {{ $plan['name'] ?: ucfirst($plan['type']) }}:
                                    @if ($plan['type'] === 'free')
                                        free
                                    @else
                                        @foreach ($plan['prices'] as $price)
                                            {{ $price['currency'] }} {{ number_format($price['price'], 2) }}@if (!$loop->last), @endif
                                        @endforeach
                                    @endif
                                </li>
                            @endforeach
                        </ul>
                        @if ($product['supported'])
                            <x-button.primary wire:click="startImport({{ $product['id'] }})" class="!w-fit mt-auto">Add to my store</x-button.primary>
                        @else
                            <p class="text-xs text-yellow-500 mt-auto">{{ $product['unsupported_reason'] }}</p>
                        @endif
                    </div>
                @empty
                    <p class="text-sm text-gray-500">Nothing left to add.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
