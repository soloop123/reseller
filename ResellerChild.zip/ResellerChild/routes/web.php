<?php

use Illuminate\Support\Facades\Route;
use Paymenter\Extensions\Servers\ResellerChild\Http\Controllers\HostApiController;
use Paymenter\Extensions\Servers\ResellerChild\Livewire\ResellerPortal;

Route::group(['middleware' => ['web', 'auth']], function () {
    Route::get('/account/reseller', ResellerPortal::class)->name('reseller.portal');
});

// Management API for SoloCloud billing (hosted mode only, bearer secret)
Route::group(['middleware' => ['api', 'throttle:60,1'], 'prefix' => 'api/reseller-host/v1'], function () {
    Route::get('/health', [HostApiController::class, 'health']);
    Route::get('/state', [HostApiController::class, 'state']);
    Route::post('/products', [HostApiController::class, 'save']);
    Route::post('/products/{id}/toggle', [HostApiController::class, 'toggle'])->whereNumber('id');
    Route::delete('/products/{id}', [HostApiController::class, 'remove'])->whereNumber('id');
});
