<?php

namespace Paymenter\Extensions\Servers\ResellerChild\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Paymenter\Extensions\Servers\ResellerChild\Support\Catalog;
use Paymenter\Extensions\Servers\ResellerChild\Support\HostConfig;

/**
 * Management API used by SoloCloud billing on behalf of the reseller. Only answers when the store runs in hosted mode
 * and the caller knows the management secret that billing generated for this store.
 */
class HostApiController extends Controller
{
    protected function guard(Request $request): ?JsonResponse
    {
        $secret = HostConfig::get('HOST_MGMT_SECRET');
        $token = (string) $request->bearerToken();

        if (!$secret || !$token || !hash_equals($secret, $token)) {
            return response()->json(['error' => 'Unauthorized.'], 401);
        }

        return null;
    }

    protected function run(Request $request, callable $fn): JsonResponse
    {
        if ($denied = $this->guard($request)) {
            return $denied;
        }
        try {
            return response()->json(['data' => $fn()]);
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
    }

    public function health(Request $request): JsonResponse
    {
        return $this->run($request, fn () => ['ok' => true]);
    }

    public function state(Request $request): JsonResponse
    {
        return $this->run($request, fn () => Catalog::make()->state($request->boolean('fresh')));
    }

    public function save(Request $request): JsonResponse
    {
        return $this->run($request, function () use ($request) {
            Catalog::make()->save($request->all());

            return Catalog::make()->state();
        });
    }

    public function toggle(Request $request, int $id): JsonResponse
    {
        return $this->run($request, fn () => ['visible' => Catalog::make()->toggle($id)]);
    }

    public function remove(Request $request, int $id): JsonResponse
    {
        return $this->run($request, fn () => ['message' => Catalog::make()->remove($id)]);
    }
}
