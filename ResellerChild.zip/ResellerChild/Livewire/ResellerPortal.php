<?php

namespace Paymenter\Extensions\Servers\ResellerChild\Livewire;

use App\Helpers\ExtensionHelper;
use App\Livewire\Component;
use App\Models\Category;
use App\Models\Currency;
use App\Models\Plan;
use App\Models\Product;
use App\Models\Server;
use App\Models\User;
use Exception;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Paymenter\Extensions\Servers\ResellerChild\Support\ParentClient;

/**
 * Client area page for the reseller account: import parent products, set own prices, publish.
 * Everything here works on customer-level permissions; the account never needs admin access.
 */
class ResellerPortal extends Component
{
    /** State of the add/edit form, null when closed. */
    public ?array $form = null;

    public static function server(): ?Server
    {
        return Server::where('extension', 'ResellerChild')->first();
    }

    public static function settings(): array
    {
        // Hosted store: connection data comes from the environment and the in-store portal stays closed
        if (\Paymenter\Extensions\Servers\ResellerChild\Support\HostConfig::active()) {
            return \Paymenter\Extensions\Servers\ResellerChild\Support\HostConfig::settings();
        }

        $server = self::server();

        return $server ? ExtensionHelper::settingsToArray($server->settings) : [];
    }

    public static function isAllowed(?User $user): bool
    {
        if (!$user) {
            return false;
        }

        $allowed = collect(explode(',', (string) (self::settings()['portal_users'] ?? '')))
            ->map(fn ($email) => Str::lower(trim($email)))
            ->filter();

        return $allowed->contains(Str::lower($user->email));
    }

    public function mount()
    {
        abort_unless(self::isAllowed(Auth::user()), 404);
    }

    public function render()
    {
        $this->authorizePortal();

        $error = null;
        $catalog = [];
        $balance = [];

        try {
            $client = $this->client();
            $catalog = $client->products();
            $balance = $client->me()['credits'] ?? [];
        } catch (Exception $e) {
            $error = $e->getMessage();
        }

        $catalog = collect($catalog);
        $managed = $this->managedProducts();
        $importedParentIds = $managed->map(fn ($p) => (int) $this->parentProductId($p))->all();

        return view('reseller-child::portal', [
            'error' => $error,
            'balance' => $balance,
            'catalog' => $catalog,
            'available' => $catalog->reject(fn ($p) => in_array($p['id'], $importedParentIds))->values(),
            'products' => $managed->map(fn ($product) => $this->describe($product, $catalog))->all(),
            'categories' => Category::orderBy('name')->pluck('name', 'id')->all(),
            'currencies' => $this->currencies(),
            'editingParent' => $this->form ? $catalog->firstWhere('id', (int) $this->form['parent_product_id']) : null,
            'allowBelow' => $this->allowBelow(),
        ])->layoutData(['sidebar' => true]);
    }

    public function refreshCatalog()
    {
        $this->authorizePortal();

        try {
            $this->client()->products(fresh: true);
            $this->notify('Catalog refreshed.', 'success');
        } catch (Exception $e) {
            $this->notify($e->getMessage(), 'error');
        }
    }

    public function startImport(int $parentProductId)
    {
        $this->authorizePortal();

        if ($this->managedProducts()->contains(fn ($p) => (int) $this->parentProductId($p) === $parentProductId)) {
            return $this->notify('You already added this product. Edit it instead.', 'error');
        }

        $parent = $this->findParentProduct($parentProductId);
        if (!$parent) {
            return $this->notify('Product is not available.', 'error');
        }
        if (!$parent['supported']) {
            return $this->notify($parent['unsupported_reason'] ?? 'This product cannot be resold yet.', 'error');
        }

        $currencies = $this->currencies();
        $cycles = [];
        foreach ($parent['plans'] as $plan) {
            $prices = [];
            foreach ($plan['prices'] as $price) {
                if (!in_array($price['currency'], $currencies, true)) {
                    continue;
                }
                $prices[$price['currency']] = [
                    // Suggest the parent's public price, but never below what it costs us
                    'price' => (string) max($price['list_price'], $price['price']),
                    'setup_fee' => (string) $price['setup_fee'],
                ];
            }
            $cycles[$plan['id']] = ['enabled' => true, 'prices' => $prices];
        }

        $this->form = [
            'product_id' => null,
            'parent_product_id' => $parent['id'],
            'name' => $parent['name'],
            'description' => (string) ($parent['description'] ?? ''),
            'category_id' => '',
            'new_category' => '',
            'visible' => false,
            'cycles' => $cycles,
        ];
    }

    public function startEdit(int $productId)
    {
        $this->authorizePortal();

        $product = $this->findManaged($productId);
        $parent = $this->findParentProduct((int) $this->parentProductId($product));

        if (!$parent) {
            return $this->notify('The parent no longer offers this product, so prices can not be edited.', 'error');
        }

        $cycles = [];
        foreach ($parent['plans'] as $plan) {
            $existing = $this->matchPlan($product, $plan);
            $prices = [];
            foreach ($plan['prices'] as $price) {
                if (!in_array($price['currency'], $this->currencies(), true)) {
                    continue;
                }
                $mine = $existing?->prices->firstWhere('currency_code', $price['currency']);
                $prices[$price['currency']] = [
                    'price' => $mine ? (string) $mine->price : '',
                    'setup_fee' => $mine ? (string) ($mine->setup_fee ?? 0) : '',
                ];
            }
            $cycles[$plan['id']] = ['enabled' => (bool) $existing, 'prices' => $prices];
        }

        $this->form = [
            'product_id' => $product->id,
            'parent_product_id' => $parent['id'],
            'name' => $product->name,
            'description' => (string) $product->description,
            'category_id' => (string) $product->category_id,
            'new_category' => '',
            'visible' => !$product->hidden,
            'cycles' => $cycles,
        ];
    }

    public function cancel()
    {
        $this->form = null;
    }

    public function save()
    {
        $this->authorizePortal();

        if (!$this->form) {
            return;
        }

        $form = $this->form;

        try {
            $parent = $this->client()->product((int) $form['parent_product_id']);
        } catch (Exception $e) {
            return $this->notify($e->getMessage(), 'error');
        }

        if (!$parent['supported']) {
            return $this->notify($parent['unsupported_reason'] ?? 'This product cannot be resold yet.', 'error');
        }

        $name = trim((string) ($form['name'] ?? ''));
        if ($name === '' || mb_strlen($name) > 100) {
            return $this->notify('Enter a product name (max 100 characters).', 'error');
        }

        $categoryId = $form['category_id'] ?? '';
        $newCategory = trim((string) ($form['new_category'] ?? ''));
        if ($newCategory === '' && !Category::whereKey($categoryId)->exists()) {
            return $this->notify('Choose a category or enter a name for a new one.', 'error');
        }
        if (mb_strlen($newCategory) > 100) {
            return $this->notify('Category name is too long.', 'error');
        }

        // Rebuild what to store from the parent's truth; only the retail prices come from the form
        $currencies = $this->currencies();
        $allowBelow = $this->allowBelow();
        $plans = [];

        foreach ($parent['plans'] as $plan) {
            $cycle = $form['cycles'][$plan['id']] ?? null;
            if (!$cycle || empty($cycle['enabled'])) {
                continue;
            }

            $prices = [];
            if ($plan['type'] !== 'free') {
                foreach ($plan['prices'] as $wholesale) {
                    $currency = $wholesale['currency'];
                    $input = $cycle['prices'][$currency] ?? [];
                    $price = trim((string) ($input['price'] ?? ''));
                    if (!in_array($currency, $currencies, true) || $price === '') {
                        continue;
                    }
                    $setup = trim((string) ($input['setup_fee'] ?? '')) === '' ? '0' : trim((string) $input['setup_fee']);

                    if (!is_numeric($price) || !is_numeric($setup) || $price < 0 || $setup < 0 || $price > 9999999 || $setup > 9999999) {
                        return $this->notify("Invalid price for {$plan['name']} ({$currency}).", 'error');
                    }
                    if (!$allowBelow && ($price < $wholesale['price'] || $setup < $wholesale['setup_fee'])) {
                        return $this->notify("{$plan['name']} ({$currency}): price and setup fee can not be lower than your wholesale cost ({$wholesale['price']} / {$wholesale['setup_fee']}).", 'error');
                    }

                    $prices[$currency] = ['price' => round((float) $price, 2), 'setup_fee' => round((float) $setup, 2)];
                }

                if (!$prices) {
                    return $this->notify("Set a price for {$plan['name']} in at least one currency, or untick that billing cycle.", 'error');
                }
            }

            $plans[] = ['parent' => $plan, 'prices' => $prices];
        }

        if (!$plans) {
            return $this->notify('Enable at least one billing cycle.', 'error');
        }

        try {
            DB::transaction(function () use ($form, $parent, $name, $categoryId, $newCategory, $plans) {
                if ($newCategory !== '') {
                    $category = Category::create([
                        'name' => $newCategory,
                        'slug' => Str::slug($newCategory) . '-' . Str::lower(Str::random(4)),
                    ]);
                    $categoryId = $category->id;
                }

                if ($form['product_id']) {
                    $product = $this->findManaged((int) $form['product_id']);
                    if ((int) $this->parentProductId($product) !== (int) $parent['id']) {
                        throw new Exception('Product mismatch.');
                    }
                    $product->update([
                        'name' => $name,
                        'description' => $form['description'] ?? '',
                        'category_id' => $categoryId,
                        'hidden' => empty($form['visible']),
                    ]);
                } else {
                    $product = Product::create([
                        'category_id' => $categoryId,
                        'name' => $name,
                        'slug' => Str::slug($name) . '-' . Str::lower(Str::random(5)),
                        'description' => $form['description'] ?? '',
                        'server_id' => self::server()->id,
                        'hidden' => empty($form['visible']),
                        'allow_quantity' => 'disabled',
                    ]);
                    $this->setSetting($product, 'parent_product_id', $parent['id']);
                    $this->setSetting($product, 'reseller_managed', '1');
                }

                $product->load('plans.prices');

                foreach ($parent['plans'] as $index => $parentPlan) {
                    $chosen = collect($plans)->first(fn ($p) => $p['parent']['id'] === $parentPlan['id']);
                    $plan = $this->matchPlan($product, $parentPlan);

                    if (!$chosen) {
                        // Cycle switched off: remove it unless customers already use it
                        if ($plan && !$plan->services()->exists()) {
                            $plan->prices()->delete();
                            $plan->delete();
                        }

                        continue;
                    }

                    if (!$plan) {
                        $plan = $product->plans()->create([
                            'name' => $parentPlan['name'],
                            'type' => $parentPlan['type'],
                            'billing_period' => $parentPlan['billing_period'],
                            'billing_unit' => $parentPlan['billing_unit'],
                            'sort' => $index,
                        ]);
                    }

                    $plan->prices()->whereNotIn('currency_code', array_keys($chosen['prices']) ?: [''])->delete();
                    foreach ($chosen['prices'] as $currency => $amounts) {
                        $plan->prices()->updateOrCreate(['currency_code' => $currency], $amounts);
                    }
                }
            });
        } catch (Exception $e) {
            report($e);

            return $this->notify('Could not save: ' . $e->getMessage(), 'error');
        }

        $this->form = null;
        $this->notify('Product saved.', 'success');
    }

    public function toggleVisibility(int $productId)
    {
        $this->authorizePortal();

        $product = $this->findManaged($productId);
        $product->update(['hidden' => !$product->hidden]);

        $this->notify($product->hidden ? 'Product is now hidden from your store.' : 'Product is now public on your store.', 'success');
    }

    public function remove(int $productId)
    {
        $this->authorizePortal();

        $product = $this->findManaged($productId);

        if ($product->services()->exists()) {
            $product->update(['hidden' => true]);

            return $this->notify('Customers already own this product, so it was hidden instead of deleted.', 'success');
        }

        DB::transaction(function () use ($product) {
            foreach ($product->plans as $plan) {
                $plan->prices()->delete();
                $plan->delete();
            }
            $product->settings()->delete();
            $product->delete();
        });

        $this->notify('Product removed.', 'success');
    }

    /* ---------- helpers ---------- */

    protected function authorizePortal(): void
    {
        abort_unless(self::isAllowed(Auth::user()), 403);
    }

    protected function client(): ParentClient
    {
        return ParentClient::fromSettings(self::settings());
    }

    protected function allowBelow(): bool
    {
        return filter_var(self::settings()['allow_below_wholesale'] ?? false, FILTER_VALIDATE_BOOLEAN);
    }

    protected function currencies(): array
    {
        return Currency::pluck('code')->all();
    }

    protected function findParentProduct(int $id): ?array
    {
        return collect($this->client()->products())->firstWhere('id', $id);
    }

    /**
     * Only products imported through this portal can be managed from it.
     *
     * @return Collection<int, Product>
     */
    protected function managedProducts(): Collection
    {
        $server = self::server();

        if (!$server) {
            return new Collection;
        }

        return Product::where('server_id', $server->id)
            ->whereHas('settings', fn ($q) => $q->where('key', 'reseller_managed')->where('value', '1'))
            ->with(['plans.prices', 'settings', 'category'])
            ->orderBy('id')
            ->get();
    }

    protected function findManaged(int $id): Product
    {
        return $this->managedProducts()->firstWhere('id', $id) ?? abort(404);
    }

    protected function parentProductId(Product $product): ?string
    {
        return $product->settings->firstWhere('key', 'parent_product_id')?->value;
    }

    protected function setSetting(Product $product, string $key, $value): void
    {
        $product->settings()->updateOrCreate(['key' => $key], ['value' => (string) $value, 'type' => 'string']);
    }

    /**
     * The product's own plan that corresponds to a parent plan (same billing cycle).
     */
    protected function matchPlan(Product $product, array $parentPlan): ?Plan
    {
        return $product->plans->first(
            fn (Plan $plan) => $plan->type === $parentPlan['type']
                && (int) $plan->billing_period === (int) $parentPlan['billing_period']
                && $plan->billing_unit === $parentPlan['billing_unit']
        );
    }

    /**
     * Row for the "my products" table: retail vs wholesale per cycle.
     */
    protected function describe(Product $product, $catalog): array
    {
        $parent = $catalog->firstWhere('id', (int) $this->parentProductId($product));
        $rows = [];

        foreach ($product->plans as $plan) {
            $parentPlan = $parent ? collect($parent['plans'])->first(
                fn ($p) => $p['type'] === $plan->type
                    && (int) $p['billing_period'] === (int) $plan->billing_period
                    && $p['billing_unit'] === $plan->billing_unit
            ) : null;

            foreach ($plan->prices as $price) {
                $wholesale = $parentPlan ? collect($parentPlan['prices'])->firstWhere('currency', $price->currency_code) : null;
                $rows[] = [
                    'plan' => $plan->name,
                    'currency' => $price->currency_code,
                    'retail' => (float) $price->price,
                    'wholesale' => $wholesale['price'] ?? null,
                    'below' => $wholesale && (float) $price->price < $wholesale['price'],
                ];
            }

            if ($plan->type === 'free') {
                $rows[] = ['plan' => $plan->name, 'currency' => '', 'retail' => 0.0, 'wholesale' => null, 'below' => false];
            }
        }

        return [
            'id' => $product->id,
            'name' => $product->name,
            'category' => $product->category?->name,
            'public' => !$product->hidden,
            'offered' => (bool) $parent && $parent['supported'],
            'services' => $product->services()->count(),
            'rows' => $rows,
        ];
    }
}
