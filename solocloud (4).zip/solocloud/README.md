# SoloCloud — Paymenter Theme

A clean, minimalist, conversion-focused theme for [Paymenter](https://paymenter.org),
inspired by the storefront-style layout used by premium marketing-first Paymenter
themes: a hero section, a features grid, your plans, and a
closing call-to-action — all sitting on top of solid, well-elevated cards instead
of glass/blur effects.

This is an **original build** made specifically for your install. It reuses
Paymenter's default theme's page structure and Livewire logic (so every route,
component, and interaction keeps working exactly as before) but replaces the
visual layer with a crisp, minimal design system, and adds a fully editable
marketing homepage on top of it.

## What's included

- A brand-new **marketing homepage** (hero, features, plans, closing CTA) —
  entirely optional, and entirely editable from the admin panel, no code required:
  - Hero badge text, title, subtitle, CTA label and price line
  - Four feature cards (icon + title + description each)
  - Plans section title (your existing product categories render underneath)
  - Closing CTA title/subtitle/button
  - A **"Simple"** layout option (Settings → Themes → SoloCloud → Homepage Layout)
    that turns off the marketing sections and just shows your plans grid, if you'd
    prefer that instead.
- Three ready-made color templates (Water, Fire, Datacenter), each with
  light and dark palettes, plus a fully custom option.
- Solid, elevated cards with soft shadows and a subtle hover lift — no glass or
  blur effects.
- A left-accent-bar active state for sidebar/nav links instead of a glow pill.
- The same handful of pre-existing dead/unused CSS classes from the base theme
  (`bg-primary-800`, `text-primary-100`, an invisible OAuth divider on the login
  page, etc.) fixed so every page renders with a real background/border instead
  of falling back to transparent.

## Color templates & modes

**Settings → Themes → SoloCloud → Color Template** switches the whole palette:

| Template | Look |
| --- | --- |
| Water (default) | Deep navy + electric blue |
| Fire | Warm charcoal + yellow / amber / orange |
| Datacenter | Graphite + server-LED green, faint rack-grid background |
| Minecraft | Grass green + dirt brown, square blocky cards, pixel headings, chunky buttons |
| Default (Custom) | Uses the color pickers at the bottom of the settings page |

Every template has a real light **and** dark palette, so the navbar toggle
works properly. **Default Mode** sets what first-time visitors see
(dark / light / follow device).

After changing the theme files, rebuild (`npm run build -- solocloud`) and
run `php artisan view:clear`.

## Background images

Each color template comes with its own background image: Water = Minecraft Snow,
Fire = Bees, Datacenter = Cloud Hosting, Minecraft = Minecraft Forest.
**Default (Custom)** has no image unless you enter a URL in
**Custom Background Image URL** (a full `https://` link, or a path inside your
Paymenter `/public` folder such as `/images/bg.jpg`).
**Background Brightness (%)** (1-200, 100 = original) and **Background Dimming**
apply to every template.

## Header

**Show "Client Area" Link In Header** adds a link to `/dashboard` in the top navigation
and mobile menu; its text is editable.

## Feature icons

Feature icons use Remix Icon names (the icon set already bundled with
Paymenter), e.g. `ri-cpu-line`, `ri-flashlight-line`, `ri-global-line`. Browse
available icons at https://remixicon.com and enter the icon's slug (the part
after `ri-` shown on each icon's page, prefixed with `ri-`) into the relevant
"Feature — Icon" setting.

## Installation

1. Copy the `solocloud` folder into your Paymenter installation's `themes/`
   directory, so you end up with `themes/solocloud/theme.php`.
2. In the Paymenter admin panel, go to **Settings → Themes** and select
   **SoloCloud**.
3. Build the theme's assets. **Important:** `npm run build` alone targets the
   `default` theme — you must pass `solocloud` explicitly, or the site will 500
   trying to load a Vite manifest that was never generated:
   ```bash
   npm install
   npm run build -- solocloud
   ```
   or, in development:
   ```bash
   npm run dev -- solocloud
   ```
4. Clear cached views/config:
   ```bash
   php artisan view:clear
   php artisan config:clear
   ```
5. Visit **Settings → Themes → SoloCloud** in the admin panel to write your
   hero copy, features, and CTA content, and to pick your brand colors.

## Notes

- Built for Paymenter's Tailwind CSS v4 based theming system.
- No JavaScript dependencies were added beyond Alpine's `x-collapse` plugin,
  which Paymenter already ships and uses elsewhere in the default theme.
- If you leave the marketing text settings empty, sensible defaults are shown
  so the homepage never looks broken or blank.
