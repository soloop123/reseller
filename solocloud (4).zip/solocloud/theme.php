<?php

return [
    'name' => 'SoloCloud',
    'author' => 'Paymenter Community',
    'url' => 'https://paymenter.org',

    'settings' => [
        // ---- Layout / behavior (same as default) ----
        [
            'name' => 'direct_checkout',
            'label' => 'Direct Checkout',
            'type' => 'checkbox',
            'default' => false,
            'database_type' => 'boolean',
            'description' => 'Don\'t show the product overview page, go directly to the checkout page',
        ],
        [
            'name' => 'small_images',
            'label' => 'Small Images',
            'type' => 'checkbox',
            'default' => false,
            'database_type' => 'boolean',
            'description' => 'Show small images in the product overview page',
        ],
        [
            'name' => 'show_category_description',
            'label' => 'Show Category Description',
            'type' => 'checkbox',
            'default' => true,
            'database_type' => 'boolean',
            'description' => 'Show the category description in the product overview page',
        ],
        [
            'name' => 'show_client_area_link',
            'label' => 'Show "Client Area" Link In Header',
            'type' => 'checkbox',
            'default' => true,
            'database_type' => 'boolean',
            'description' => 'Adds a link to /dashboard in the top navigation (desktop and mobile menu).',
        ],
        [
            'name' => 'client_area_label',
            'label' => 'Client Area Link Text',
            'type' => 'text',
            'default' => 'Client Area',
        ],
        [
            'name' => 'logo_display',
            'label' => 'Logo display',
            'type' => 'select',
            'options' => [
                'logo-only' => 'Logo only',
                'logo-and-name' => 'Logo and Name',
            ],
            'default' => 'logo-and-name',
        ],

        // ---- Color template ----
        [
            'name' => 'template',
            'label' => 'Color Template',
            'type' => 'select',
            'options' => [
                'custom' => 'Default (Custom) - your own colors, no background image unless you add one',
                'water' => 'Water (blue) - Minecraft Snow background',
                'fire' => 'Fire (yellow / amber) - Bees background',
                'datacenter' => 'Datacenter (graphite + LED green) - Cloud Hosting background',
                'minecraft' => 'Minecraft (grass + dirt, pixel style) - Minecraft Forest background',
            ],
            'default' => 'water',
            'description' => 'Each template has its own colors (light + dark) and its own background image. Choose "Default (Custom)" to use the color pickers at the bottom of this page and an optional custom background image.',
        ],
        [
            'name' => 'default_mode',
            'label' => 'Default Mode',
            'type' => 'select',
            'options' => [
                'dark' => 'Dark',
                'light' => 'Light',
                'system' => 'Follow visitor\'s device',
            ],
            'default' => 'dark',
            'description' => 'Mode shown to first-time visitors. Visitors can still switch with the toggle in the navbar.',
        ],

        // ---- Background image (Dimming + Brightness apply to every template) ----
        [
            'name' => 'background_custom_url',
            'label' => 'Custom Background Image URL (Default (Custom) template only)',
            'type' => 'text',
            'default' => '',
            'description' => 'Only used when Color Template = Default (Custom). Paste a full https:// link, or a path to a file in your /public folder such as /images/bg.jpg. Leave empty for no image. Use a wide image (1920x1080 or larger).',
        ],
        [
            'name' => 'background_brightness',
            'label' => 'Background Brightness (%)',
            'type' => 'text',
            'default' => '100',
            'description' => 'Number from 1 to 200. 100 = original image, 50 = half as bright (dull), 150 = brighter. Lower it if your image is too bright, raise it if it is too dark.',
        ],
        [
            'name' => 'background_overlay',
            'label' => 'Background Dimming',
            'type' => 'select',
            'options' => [
                'light' => 'Light - image clearly visible',
                'medium' => 'Medium (recommended)',
                'strong' => 'Strong - best text readability',
            ],
            'default' => 'medium',
            'description' => 'How strongly the page color is laid over the image so text stays readable.',
        ],

        // ---- Marketing homepage ----
        [
            'name' => 'home_layout',
            'label' => 'Homepage Layout',
            'type' => 'select',
            'options' => [
                'marketing' => 'Marketing (hero, features, plans)',
                'simple' => 'Simple (just plans)',
            ],
            'default' => 'marketing',
            'description' => 'Marketing shows the full storefront homepage below. Simple only shows the plans grid.',
        ],
        [
            'name' => 'hero_badge_text',
            'label' => 'Hero — Badge Text',
            'type' => 'text',
            'default' => 'Trusted by hosting businesses worldwide',
        ],
        [
            'name' => 'hero_title',
            'label' => 'Hero — Title',
            'type' => 'text',
            'default' => 'Powerful hosting, delivered instantly',
        ],
        [
            'name' => 'hero_subtitle',
            'label' => 'Hero — Subtitle',
            'type' => 'textarea',
            'default' => 'Fast, reliable VPS, game and web hosting built for speed, stability, and performance.',
        ],
        [
            'name' => 'hero_cta_label',
            'label' => 'Hero — Button Label',
            'type' => 'text',
            'default' => 'Get Started',
        ],
        [
            'name' => 'hero_price_text',
            'label' => 'Hero — Price Line',
            'type' => 'text',
            'default' => 'Starting at only $4.99/month',
        ],
        [
            'name' => 'show_features',
            'label' => 'Show Features Section',
            'type' => 'checkbox',
            'default' => true,
            'database_type' => 'boolean',
        ],
        [
            'name' => 'features_title',
            'label' => 'Features — Title',
            'type' => 'text',
            'default' => 'Everything you need to get started',
        ],
        [
            'name' => 'feature_1_icon',
            'label' => 'Feature 1 — Icon (Remix Icon name, e.g. ri-cpu-line)',
            'type' => 'text',
            'default' => 'ri-cpu-line',
        ],
        [
            'name' => 'feature_1_title',
            'label' => 'Feature 1 — Title',
            'type' => 'text',
            'default' => 'Powered by the latest hardware',
        ],
        [
            'name' => 'feature_1_text',
            'label' => 'Feature 1 — Description',
            'type' => 'textarea',
            'default' => 'NVMe SSDs, the latest-generation CPUs and DDR5 memory keep your services fast and responsive.',
        ],
        [
            'name' => 'feature_2_icon',
            'label' => 'Feature 2 — Icon',
            'type' => 'text',
            'default' => 'ri-flashlight-line',
        ],
        [
            'name' => 'feature_2_title',
            'label' => 'Feature 2 — Title',
            'type' => 'text',
            'default' => 'Up and running in minutes',
        ],
        [
            'name' => 'feature_2_text',
            'label' => 'Feature 2 — Description',
            'type' => 'textarea',
            'default' => 'A simple checkout deploys your server instantly. No complicated setup, no waiting around.',
        ],
        [
            'name' => 'feature_3_icon',
            'label' => 'Feature 3 — Icon',
            'type' => 'text',
            'default' => 'ri-customer-service-2-line',
        ],
        [
            'name' => 'feature_3_title',
            'label' => 'Feature 3 — Title',
            'type' => 'text',
            'default' => 'Real human support',
        ],
        [
            'name' => 'feature_3_text',
            'label' => 'Feature 3 — Description',
            'type' => 'textarea',
            'default' => 'Reach our team any time over ticket or chat and get help from people who know hosting.',
        ],
        [
            'name' => 'feature_4_icon',
            'label' => 'Feature 4 — Icon',
            'type' => 'text',
            'default' => 'ri-global-line',
        ],
        [
            'name' => 'feature_4_title',
            'label' => 'Feature 4 — Title',
            'type' => 'text',
            'default' => 'Low latency, worldwide',
        ],
        [
            'name' => 'feature_4_text',
            'label' => 'Feature 4 — Description',
            'type' => 'textarea',
            'default' => 'Deploy close to your customers with infrastructure spread across multiple regions.',
        ],
        [
            'name' => 'plans_title',
            'label' => 'Plans Section — Title',
            'type' => 'text',
            'default' => 'Plans built for every project',
        ],
        [
            'name' => 'cta_title',
            'label' => 'Closing CTA — Title',
            'type' => 'text',
            'default' => 'Ready to get started?',
        ],
        [
            'name' => 'cta_subtitle',
            'label' => 'Closing CTA — Subtitle',
            'type' => 'textarea',
            'default' => 'Have questions or need a custom solution? Our team is here to help you find the right plan.',
        ],
        [
            'name' => 'cta_button_label',
            'label' => 'Closing CTA — Button Label',
            'type' => 'text',
            'default' => 'Get Started',
        ],

        // ---- Colors (only used when Color Template = Custom) ----
        [
            'name' => 'primary',
            'label' => 'Primary - Brand Color (Light)',
            'type' => 'color',
            'default' => 'hsl(201, 96%, 40%)',
        ],
        [
            'name' => 'secondary',
            'label' => 'Secondary - Brand Color (Light)',
            'type' => 'color',
            'default' => 'hsl(210, 100%, 40%)',
        ],
        [
            'name' => 'neutral',
            'label' => 'Borders, Accents... (Light)',
            'type' => 'color',
            'default' => 'hsl(214, 32%, 88%)',
        ],
        [
            'name' => 'base',
            'label' => 'Base - Text Color (Light)',
            'type' => 'color',
            'default' => 'hsl(222, 47%, 11%)',
        ],
        [
            'name' => 'muted',
            'label' => 'Muted - Text Color (Light)',
            'type' => 'color',
            'default' => 'hsl(215, 16%, 40%)',
        ],
        [
            'name' => 'inverted',
            'label' => 'Inverted - Text Color (Light)',
            'type' => 'color',
            'default' => 'hsl(0, 0%, 100%)',
        ],
        [
            'name' => 'background',
            'label' => 'Background - Color (Light)',
            'type' => 'color',
            'default' => 'hsl(210, 40%, 98%)',
        ],
        [
            'name' => 'background-secondary',
            'label' => 'Background - Secondary Color (Light)',
            'type' => 'color',
            'default' => 'hsl(0, 0%, 100%)',
        ],

        // ---- Colors: dark mode ----
        [
            'name' => 'dark-primary',
            'label' => 'Primary - Brand Color (Dark)',
            'type' => 'color',
            'default' => 'hsl(199, 100%, 50%)',
        ],
        [
            'name' => 'dark-secondary',
            'label' => 'Secondary - Brand Color (Dark)',
            'type' => 'color',
            'default' => 'hsl(210, 100%, 40%)',
        ],
        [
            'name' => 'dark-neutral',
            'label' => 'Borders, Accents... (Dark)',
            'type' => 'color',
            'default' => 'hsl(223, 24%, 16%)',
        ],
        [
            'name' => 'dark-base',
            'label' => 'Base - Text Color (Dark)',
            'type' => 'color',
            'default' => 'hsl(210, 40%, 98%)',
        ],
        [
            'name' => 'dark-muted',
            'label' => 'Muted - Text Color (Dark)',
            'type' => 'color',
            'default' => 'hsl(215, 20%, 65%)',
        ],
        [
            'name' => 'dark-inverted',
            'label' => 'Inverted - Text Color (Dark)',
            'type' => 'color',
            'default' => 'hsl(0, 0%, 100%)',
        ],
        [
            'name' => 'dark-background',
            'label' => 'Background - Color (Dark)',
            'type' => 'color',
            'default' => 'hsl(224, 71%, 4%)',
        ],
        [
            'name' => 'dark-background-secondary',
            'label' => 'Background - Secondary Color (Dark)',
            'type' => 'color',
            'default' => 'hsl(223, 49%, 8%)',
        ],
    ],
];
