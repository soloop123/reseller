@php
    $layout = theme('home_layout', 'marketing');
@endphp

<div>
    @if ($layout === 'marketing')
    {{-- ============ HERO ============ --}}
    <section class="solo-hero">
        <div class="container py-20 md:py-28 flex flex-col items-center text-center gap-6">
            @if (theme('hero_badge_text'))
            <div class="solo-card inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold text-base/70">
                <x-ri-shield-check-line class="size-4 text-primary" />
                {{ theme('hero_badge_text') }}
            </div>
            @endif

            <h1 class="text-4xl md:text-6xl font-bold tracking-tight max-w-3xl text-balance">
                {{ theme('hero_title', 'Powerful hosting, delivered instantly') }}
            </h1>

            <p class="text-lg text-base/60 max-w-2xl text-pretty">
                {{ theme('hero_subtitle') }}
            </p>

            <div class="flex flex-col items-center gap-3 mt-2">
                <a href="#plans">
                    <x-button.primary class="!w-auto">
                        {{ theme('hero_cta_label', 'Get Started') }}
                        <x-ri-arrow-right-line class="size-5" />
                    </x-button.primary>
                </a>
                @if (theme('hero_price_text'))
                <span class="text-sm text-base/50">{{ theme('hero_price_text') }}</span>
                @endif
            </div>
        </div>
    </section>

    {{-- ============ FEATURES ============ --}}
    @if (theme('show_features', true))
    <section class="container py-20">
        <div class="text-center max-w-2xl mx-auto mb-12">
            <p class="solo-eyebrow mb-2">{{ __('Features you will love') }}</p>
            <h2 class="text-3xl font-bold tracking-tight solo-gradient-text pb-1">{{ theme('features_title', 'Everything you need to get started') }}</h2>
        </div>
        <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            @for ($i = 1; $i <= 4; $i++)
                @php
                    $icon = theme("feature_{$i}_icon");
                    $ftitle = theme("feature_{$i}_title");
                    $ftext = theme("feature_{$i}_text");
                @endphp
                @if ($ftitle)
                <div class="solo-card p-6 rounded-xl flex flex-col gap-3">
                    <div class="bg-primary/10 text-primary size-11 flex items-center justify-center rounded-lg">
                        <x-dynamic-component :component="$icon ?: 'ri-star-line'" class="size-6" />
                    </div>
                    <h3 class="text-lg font-semibold">{{ $ftitle }}</h3>
                    <p class="text-sm text-base/60">{{ $ftext }}</p>
                </div>
                @endif
            @endfor
        </div>
    </section>
    @endif
    @endif

    {{-- ============ PLANS ============ --}}
    <section id="plans" class="container pb-20 {{ $layout === 'simple' ? 'pt-14' : '' }}">
        @if ($layout === 'marketing')
        <div class="text-center max-w-2xl mx-auto mb-12">
            <p class="solo-eyebrow mb-2">{{ __('Plans') }}</p>
            <h2 class="text-3xl font-bold tracking-tight solo-gradient-text pb-1">{{ theme('plans_title', 'Plans built for every project') }}</h2>
        </div>
        @else
        <h2 class="text-xl font-semibold mb-6">{{ __('Services') }}</h2>
        @endif

        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
            @foreach ($categories as $category)
            <div class="flex flex-col solo-card solo-card-hover p-4 rounded-xl">
                @if(theme('small_images', false))
                <div class="flex gap-x-3 items-center">
                    @endif
                    @if ($category->image)
                    <img src="{{ Storage::url($category->image) }}" alt="{{ $category->name }}"
                        class="aspect-square rounded-lg {{ theme('small_images', false) ? 'w-14 h-fit' : 'w-full object-cover object-center' }}">
                    @endif
                    <div class="flex justify-between items-center">
                        <h3 class="text-xl font-semibold">{{ $category->name }}</h3>
                    </div>
                    @if(theme('small_images', false))
                </div>
                @endif
                @if(theme('show_category_description', true))
                <article class="prose dark:prose-invert mt-2">
                    {!! $category->description !!}
                </article>
                @endif
                <a href="{{ route('category.show', ['category' => $category->slug]) }}" wire:navigate class="mt-auto pt-2">
                    <x-button.primary>
                        {{ __('common.button.view_all') }}
                        <x-ri-arrow-right-fill class="size-5" />
                    </x-button.primary>
                </a>
            </div>
            @endforeach
        </div>
    </section>

    @if ($layout === 'marketing')
    {{-- ============ CLOSING CTA ============ --}}
    <section class="container pb-20">
        <div class="solo-card rounded-2xl p-10 md:p-16 flex flex-col items-center text-center gap-4 border-primary/20">
            <h2 class="text-3xl font-bold tracking-tight solo-gradient-text pb-1">{{ theme('cta_title', 'Ready to get started?') }}</h2>
            <p class="text-base/60 max-w-xl">{{ theme('cta_subtitle') }}</p>
            <a href="{{ route('register') }}" wire:navigate class="mt-2">
                <x-button.primary class="!w-auto">
                    {{ theme('cta_button_label', 'Get Started') }}
                </x-button.primary>
            </a>
        </div>
    </section>
    @endif

    {!! hook('pages.home') !!}
</div>
