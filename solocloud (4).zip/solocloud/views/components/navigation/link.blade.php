@props(['href', 'spa' => true])
<a href="{{ $href }}" {{ $attributes->merge(['class' => 'flex flex-row items-center p-3 gap-2 text-sm font-semibold text-wrap rounded-lg transition-colors duration-150 ' . ($href === request()->url() ? 'text-primary solo-nav-active' : 'text-base hover:text-base/80 hover:bg-background-secondary')]) }} @if($spa) wire:navigate @endif>
    {{ $slot }}
</a>