<div class="flex min-h-[100vh]">
    <div class="justify-center flex flex-1 min-h-full flex-col mx-4">
        <div class="mx-auto container">
            <div
                class="solo-card mx-auto flex flex-col gap-2 mt-4 px-6 sm:px-14 pb-10 rounded-xl xl:max-w-[700px] w-full">
                    {{ $slot }}
            </div>
        </div>
    </div>
</div>